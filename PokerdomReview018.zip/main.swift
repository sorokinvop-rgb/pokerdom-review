import Cocoa
import Vision
import CoreImage
import ImageIO
import CryptoKit
var lastOCR=""
var archivedShowdown = false
var baseReport=""
var analysisText=""
var savedText=""
func refreshReport(){ output.string = [baseReport,analysisText,savedText].filter{ !$0.isEmpty }.joined(separator:"\n\n") }
func imageDigest(_ url:URL)throws->String { SHA256.hash(data:try Data(contentsOf:url)).map{String(format:"%02x",Int($0))}.joined() }
let app = NSApplication.shared
app.setActivationPolicy(.regular)
let window = NSWindow(contentRect:NSRect(x:0,y:0,width:800,height:650),styleMask:[.titled,.closable,.resizable],backing:.buffered,defer:false)
window.title="Pokerdom Review 0.18 — архив раздач"
let root=NSStackView(); root.orientation = .vertical; root.alignment = .leading; root.spacing=12; root.edgeInsets=NSEdgeInsets(top:16,left:16,bottom:16,right:16)
window.contentView=root
let intro=NSTextField(wrappingLabelWithString:"Версия 0.18. Откройте сохранённый скриншот завершённой раздачи. Распознавание локальное; карты и суммы требуют проверки. Программа не подключается к игровому столу.")
root.addArrangedSubview(intro)
let preview=NSImageView(); preview.imageScaling = .scaleProportionallyUpOrDown; root.addArrangedSubview(preview); preview.heightAnchor.constraint(equalToConstant:310).isActive=true; preview.widthAnchor.constraint(equalTo:root.widthAnchor,constant:-32).isActive=true
let output=NSTextView(); output.isEditable=false; output.font=NSFont.monospacedSystemFont(ofSize:13,weight:.regular)
let scroll=NSScrollView(); scroll.documentView=output; scroll.hasVerticalScroller=true; root.addArrangedSubview(scroll); scroll.widthAnchor.constraint(equalTo:root.widthAnchor,constant:-32).isActive=true; scroll.heightAnchor.constraint(greaterThanOrEqualToConstant:180).isActive=true
func extract(_ text:String,_ pattern:String)->String? {
 guard let regex=try? NSRegularExpression(pattern:pattern,options:[.caseInsensitive]), let m=regex.firstMatch(in:text,range:NSRange(text.startIndex...,in:text)), let r=Range(m.range(at:1),in:text) else{return nil}; return String(text[r])
}
class Actions:NSObject {
 var archive:URL?
 var timer:Timer?
 var processed=Set<String>()
 var pending=Set<String>()
 @objc func showOCR(){ let alert=NSAlert(); alert.messageText="Исходный OCR"; alert.informativeText=lastOCR; alert.runModal() }
 @objc func journal(){ let dir=FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Documents/Pokerdom Review"); try? FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true,attributes:nil); NSWorkspace.shared.open(dir) }
 @objc func watch(){ let panel=NSOpenPanel(); panel.message="Выберите отдельную папку только с завершёнными раздачами"; panel.canChooseFiles=false; panel.canChooseDirectories=true; guard panel.runModal() == .OK, let dir=panel.url else{return}; archive=dir; pending.removeAll(); timer?.invalidate(); timer=Timer.scheduledTimer(timeInterval:15,target:self,selector:#selector(scan),userInfo:nil,repeats:true); status.stringValue="Архив: \(dir.lastPathComponent)"; scan() }
 @objc func stop(){timer?.invalidate(); timer=nil; archive=nil; status.stringValue="Автоимпорт выключен"}
 @objc func scan(){guard let dir=archive else{return}; let files=(try? FileManager.default.contentsOfDirectory(at:dir,includingPropertiesForKeys:nil)) ?? []; var current=Set<String>(); for url in files where ["png","jpg","jpeg"].contains(url.pathExtension.lowercased()) { guard let digest=try? imageDigest(url) else{continue}; current.insert(digest); if pending.contains(digest) && !processed.contains(digest){process(url); processed.insert(digest)} }; pending=current }


 @objc func open(){
 let panel=NSOpenPanel(); panel.allowedFileTypes=["png","jpg","jpeg"]; guard panel.runModal() == .OK, let url=panel.url else{return}
 process(url)
 }
 @objc func folder(){
 let panel=NSOpenPanel(); panel.canChooseFiles=false; panel.canChooseDirectories=true; guard panel.runModal() == .OK, let dir=panel.url else{return}
 let files=(try? FileManager.default.contentsOfDirectory(at:dir,includingPropertiesForKeys:nil)) ?? []
 var count=0
 for url in files.sorted(by:{$0.path<$1.path}) where ["png","jpg","jpeg"].contains(url.pathExtension.lowercased()) { process(url); count += 1 }
 output.string += "\nОбработано файлов: \(count)"
 }
 func process(_ url:URL){
 archivedShowdown=false; heroField.stringValue=""; oppField.stringValue=""; boardField.stringValue=""; format.state = .off; preview.image=NSImage(contentsOf:url); baseReport=""; analysisText=""; savedText=""; output.string="Распознавание…"
 let request=VNRecognizeTextRequest(); request.recognitionLevel = .accurate; request.recognitionLanguages=["ru-RU","en-US"]
 do {
 try VNImageRequestHandler(url:url,options:[:]).perform([request])
 let lines=(request.results ?? []).compactMap{$0.topCandidates(1).first?.string}
 let raw=lines.joined(separator:"\n")
 let bank=extract(raw,#"банк[ \t]*[:：]?[ \t]*([0-9]+(?:[ \u00a0][0-9]{3})*)(?![0-9.,])"#) ?? "не распознан"
 let foundCombos=lines.filter{line in ["фулл-хаус","две пары","стрит","флеш","каре","тройка","сет","пара"].contains{line.lowercased().contains($0)}}
 var seen=Set<String>()
 let combos=foundCombos.filter{seen.insert($0.lowercased().trimmingCharacters(in:.whitespaces)).inserted}
 let lower=raw.lowercased()
 let shortDeck=raw.contains("6+")
 let omaha=lower.contains("омаха") || lower.contains("omaha")
 let game=omaha ? "Омаха" : (shortDeck ? "6+ Холдем" : (lower.contains("холдем") || lower.contains("holdem") ? "Холдем" : "не определён"))
 format.state = shortDeck ? .on : .off
 let seats:[(String,Double,Double)] = [("Слева сверху",0.14,0.58),("Сверху",0.51,0.72),("Справа сверху",0.88,0.58),("Слева снизу",0.13,0.18),("Справа снизу",0.89,0.18),("Снизу",0.51,0.035)]
 let stackCandidates=seats.map { seat -> String in
   let value=readSeatStack(url, x:seat.1, y:seat.2)
   return "\(seat.0): \(value.map(String.init) ?? "не распознан")"
 }
 let detected = omaha ? nil : recognizeArchivedCards(url)
 if let (h,o,b)=detected { heroField.stringValue=h; oppField.stringValue=o; boardField.stringValue=b }
 archivedShowdown = !omaha && combos.count >= 2 && detected != nil
 let cardReport = detected == nil ? "Карты: не распознаны уверенно; проверьте вручную." : "Карты: предварительно заполнены; подтвердите визуально перед разбором."
 let report="Файл: \(url.lastPathComponent)\nБанк: \(bank)\nФормат: \(game)\nКомбинации: \(combos.isEmpty ? "не распознаны" : combos.joined(separator:"; "))\nСтеки (проверьте):\n\(stackCandidates.joined(separator: "\n"))\n\(cardReport)\nСтатус: \(archivedShowdown ? "кандидат на завершённую раздачу" : "завершение не подтверждено; личные карты не установлены")"
 if archivedShowdown { analysisText = "Сверьте карты и формат игры, затем нажмите «Разбор»." }
 lastOCR=raw
 baseReport=report; refreshReport()
 let dir=FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Documents/Pokerdom Review")
 do {try FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true,attributes:nil); try (report+"\n\n"+analysisText).write(to:dir.appendingPathComponent((try imageDigest(url))+".txt"),atomically:true,encoding:.utf8); savedText="Отчёт сохранён в Документы/Pokerdom Review"; refreshReport()} catch {output.string += "\n\nНе удалось сохранить отчёт: \(error.localizedDescription)"}
 } catch {output.string="Ошибка: \(error.localizedDescription)"}
 }
}
let fields=NSStackView(); fields.orientation = .horizontal
let heroField=NSTextField(string: ""); heroField.placeholderString="Ваши карты"
let oppField=NSTextField(string: ""); oppField.placeholderString="Карты соперника"
let boardField=NSTextField(string: ""); boardField.placeholderString="Карты стола"
let format=NSButton(checkboxWithTitle:"6+",target:nil,action:nil)
for f in [heroField,oppField,boardField] {f.widthAnchor.constraint(equalToConstant:f === boardField ? 220:140).isActive=true; fields.addArrangedSubview(f)}
fields.addArrangedSubview(format)
class MathAction:NSObject { @objc func calculate(){guard archivedShowdown else {analysisText="Разбор доступен только для подтверждённой завершённой раздачи Холдема."; refreshReport(); return}; guard let h=parseCards(heroField.stringValue),let o=parseCards(oppField.stringValue),let b=parseCards(boardField.stringValue) else {output.string += "\nПроверьте формат карт: KS KD (C/D/H/S).";return}; analysisText=retrospective(h,o,b,short:format.state == .on); refreshReport() } }
let mathAction=MathAction(); fields.addArrangedSubview(NSButton(title:"Разбор",target:mathAction,action:#selector(MathAction.calculate))); root.insertArrangedSubview(fields,at:1)
let actions=Actions(); let button=NSButton(title:"Открыть скриншот",target:actions,action:#selector(Actions.open)); let controls=NSStackView(views:[button,NSButton(title:"Папка раздач",target:actions,action:#selector(Actions.folder)),NSButton(title:"Показать OCR",target:actions,action:#selector(Actions.showOCR))]); root.insertArrangedSubview(controls,at:1)
let status=NSTextField(labelWithString:"Автоимпорт выключен")
let archiveControls=NSStackView(views:[NSButton(title:"Следить за архивом",target:actions,action:#selector(Actions.watch)),NSButton(title:"Остановить",target:actions,action:#selector(Actions.stop)),NSButton(title:"Журнал отчётов",target:actions,action:#selector(Actions.journal)),status]); root.insertArrangedSubview(archiveControls,at:2)
let updateAction = UpdateAction()
root.insertArrangedSubview(NSStackView(views:[NSButton(title:"Проверить обновления",target:updateAction,action:#selector(UpdateAction.check)),NSButton(title:"Установить ZIP…",target:updateAction,action:#selector(UpdateAction.install))]),at:1)
window.isReleasedWhenClosed=false; window.center(); window.makeKeyAndOrderFront(nil); app.activate(ignoringOtherApps:true); DispatchQueue.main.async { updateAction.checkRemote(silent:true) }; app.run()

// Read the numeric line independently at two scales and with enhanced contrast.
func readSeatStack(_ url:URL,x:Double,y:Double)->Int? {
 guard let source=CGImageSourceCreateWithURL(url as CFURL,nil),let image=CGImageSourceCreateImageAtIndex(source,0,nil) else{return nil}
 let w=CGFloat(image.width),h=CGFloat(image.height)
 let region=CGRect(x:max(0,x-0.12)*w,y:max(0,1-y-0.085)*h,width:min(0.24,1-max(0,x-0.12))*w,height:min(0.18,1-max(0,1-y-0.085))*h).integral
 guard let crop=image.cropping(to:region) else{return nil}
 let ci=CIImage(cgImage:crop); let context=CIContext(options:nil)
 let variants=[ci,ci.applyingFilter("CIColorControls",parameters:[kCIInputSaturationKey:0,kCIInputContrastKey:1.6]),ci.applyingFilter("CIColorControls",parameters:[kCIInputSaturationKey:0,kCIInputBrightnessKey:0.15,kCIInputContrastKey:1.3])]
 var votes=[Int:Int]()
 for variant in variants {
   let scaled=variant.transformed(by:CGAffineTransform(scaleX:3,y:3))
   guard let cg=context.createCGImage(scaled,from:scaled.extent) else{continue}
   let req=VNRecognizeTextRequest(); req.recognitionLevel = .accurate; req.recognitionLanguages=["en-US"]; req.usesLanguageCorrection=false
   guard (try? VNImageRequestHandler(cgImage:cg,options:[:]).perform([req])) != nil else{continue}
   let candidates=(req.results ?? []).compactMap { obs -> (Int,CGFloat)? in
      guard let c=obs.topCandidates(1).first,c.confidence >= 0.65 else{return nil}
      let t=c.string.filter{ !$0.isWhitespace }; guard t.range(of:#"^[0-9]+$"#,options:.regularExpression) != nil,let n=Int(t) else{return nil}
      let distance=abs(obs.boundingBox.midY - 0.5)
      return (n,distance)
   }.sorted{$0.1 < $1.1}
   if let first=candidates.first, candidates.count == 1 || candidates[1].1-first.1 > 0.12 {votes[first.0,default:0]+=1}
 }
 let ordered=votes.sorted{$0.value > $1.value}; guard let first=ordered.first,first.value>=2,ordered.count==1 || first.value>ordered[1].value else{return nil}; return first.key
}
