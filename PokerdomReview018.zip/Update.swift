import Cocoa
import CryptoKit
final class UpdateAction: NSObject {
 private var checking = false
 @objc func check() { checkRemote(silent:false) }
 func checkRemote(silent:Bool) {
  guard !checking else {return}; checking=true
  let nonce=UUID().uuidString
  let urls = ["https://api.github.com/repos/sorokinvop-rgb/pokerdom-review/contents/update.json?ref=main&nonce=\(nonce)", "https://raw.githubusercontent.com/sorokinvop-rgb/pokerdom-review/main/update.json?nonce=\(nonce)"]
  fetch(urls, index:0, errors:[], candidates:[], silent:silent)
 }
 private let freshSession:URLSession = {
  let config=URLSessionConfiguration.ephemeral
  config.urlCache=nil
  config.requestCachePolicy = .reloadIgnoringLocalCacheData
  return URLSession(configuration:config)
 }()
 private func fetch(_ urls:[String], index:Int, errors:[String], candidates:[Manifest], silent:Bool) {
  guard index < urls.count else {
   DispatchQueue.main.async {
    self.checking=false
    let old=Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0"
    let newest=candidates.max { $0.version.compare($1.version,options:.numeric) == .orderedAscending }
    if let manifest=newest, manifest.version.compare(old,options:.numeric) == .orderedDescending {self.offer(manifest);return}
    if !silent {
     if candidates.count == urls.count {self.notice("Установлена актуальная версия \(old)")}
     else {self.notice("Не удалось подтвердить актуальность версии \(old).\n"+errors.joined(separator:"\n"))}
    }
   };return
  }
  var request=URLRequest(url:URL(string:urls[index])!,cachePolicy:.reloadIgnoringLocalCacheData,timeoutInterval:10)
  request.setValue("PokerdomReview/0.18",forHTTPHeaderField:"User-Agent")
  request.setValue("application/vnd.github.raw+json",forHTTPHeaderField:"Accept")
  request.setValue("no-cache, no-store, max-age=0",forHTTPHeaderField:"Cache-Control")
  request.setValue("no-cache",forHTTPHeaderField:"Pragma")
  freshSession.dataTask(with:request) { data,response,error in
   do {
    if let error=error {throw error}
    guard let http=response as? HTTPURLResponse, http.statusCode == 200, let data=data else {throw NSError(domain:"HTTP",code:(response as? HTTPURLResponse)?.statusCode ?? -1)}
    let manifest:Manifest
    if let direct=try? JSONDecoder().decode(Manifest.self,from:data) {manifest=direct}
    else {let envelope=try JSONDecoder().decode(GitHubEnvelope.self,from:data);guard let decoded=Data(base64Encoded:envelope.content,options:.ignoreUnknownCharacters) else {throw NSError(domain:"Manifest",code:1)};manifest=try JSONDecoder().decode(Manifest.self,from:decoded)}
    self.fetch(urls,index:index+1,errors:errors,candidates:candidates+[manifest],silent:silent)
   } catch {self.fetch(urls,index:index+1,errors:errors+["\(urls[index]): \(error.localizedDescription)"],candidates:candidates,silent:silent)}
  }.resume()
 }
 private struct GitHubEnvelope:Decodable {let content:String}
 private struct Manifest:Decodable {let version:String; let url:String?; let sha256:String?; let signature:String?}
 private func offer(_ manifest:Manifest) {
  guard let address=manifest.url, let url=URL(string:address), url.scheme == "https", url.host == "raw.githubusercontent.com", url.path.hasPrefix("/sorokinvop-rgb/pokerdom-review/"), let expected=manifest.sha256, let signature=manifest.signature, let sig=Data(base64Encoded:signature) else {notice("Нет подписанного пакета обновления.");return}
  let a=NSAlert(); a.messageText="Доступна версия \(manifest.version)"; a.addButton(withTitle:"Обновить"); a.addButton(withTitle:"Позже"); guard a.runModal() == .alertFirstButtonReturn else{return}
  checking=true
  URLSession.shared.dataTask(with:url) { data,response,error in
   DispatchQueue.main.async {
    defer {self.checking=false}
    do {
     if let error=error {throw error}
     guard let data=data, (response as? HTTPURLResponse)?.statusCode == 200, data.count <= 10_000_000 else {throw NSError(domain:"Update download",code:1)}
     let key=try Curve25519.Signing.PublicKey(rawRepresentation:Data(base64Encoded:"k8TUSVbW9T2eRd7DgRjViAeIJxkD81LYYI7Bgvc9lxg=")!)
     guard key.isValidSignature(sig,for:data) else {throw NSError(domain:"Update signature",code:1,userInfo:[NSLocalizedDescriptionKey:"Подпись обновления недействительна"])}
     try self.installPackage(data,expected:expected,requiredVersion:manifest.version)
    } catch {self.notice(error.localizedDescription)}
   }
  }.resume()
 }
 private func notice(_ message:String) {let a=NSAlert();a.messageText=message;a.runModal()}

 func run(_ path:String,_ args:[String],_ log:URL)throws {
  let p=Process(); p.executableURL=URL(fileURLWithPath:path); p.arguments=args
  FileManager.default.createFile(atPath:log.path,contents:nil)
  let h=try FileHandle(forWritingTo:log); defer {try? h.close()}; p.standardOutput=h; p.standardError=h
  try p.run(); p.waitUntilExit(); if p.terminationStatus != 0 {throw NSError(domain:"Update",code:Int(p.terminationStatus),userInfo:[NSLocalizedDescriptionKey:(try? String(contentsOf:log)) ?? "Ошибка сборки"])}
 }
 @objc func install() {
  let panel=NSOpenPanel(); panel.allowedFileTypes=["zip"]; panel.message="Выберите доверенный ZIP с исходниками обновления"
  guard panel.runModal() == .OK, let url=panel.url else{return}
  let alert=NSAlert(); alert.messageText="Проверка пакета"; alert.informativeText="Введите SHA-256 из доверенного источника. Пакет содержит исполняемый код. Устанавливайте только версии, которым доверяете."
  let field=NSTextField(string:""); field.frame=NSRect(x:0,y:0,width:450,height:24); alert.accessoryView=field; alert.addButton(withTitle:"Проверить и установить"); alert.addButton(withTitle:"Отмена")
  guard alert.runModal() == .alertFirstButtonReturn else{return}
  let expected=field.stringValue.trimmingCharacters(in:.whitespacesAndNewlines).lowercased()
  do {
   try installPackage(Data(contentsOf:url),expected:expected,requiredVersion:nil)
  } catch {let a=NSAlert(error:error); a.runModal()}
 }
 private func installPackage(_ data:Data,expected:String,requiredVersion:String?) throws {
   let fm=FileManager.default; let actual=SHA256.hash(data:data).map{String(format:"%02x",Int($0))}.joined()
   guard expected.count == 64, actual == expected else {throw NSError(domain:"Update",code:1,userInfo:[NSLocalizedDescriptionKey:"SHA-256 не совпадает."])}
   let current=Bundle.main.bundleURL; guard current.pathExtension == "app", current.lastPathComponent == "Pokerdom Review.app" else {throw NSError(domain:"Update",code:2,userInfo:[NSLocalizedDescriptionKey:"Запустите установленное приложение."])}
   let temp=current.deletingLastPathComponent().appendingPathComponent(".review-update-"+UUID().uuidString); try fm.createDirectory(at:temp,withIntermediateDirectories:false); defer {try? fm.removeItem(at:temp)}
   let archive=temp.appendingPathComponent("package.zip"); try data.write(to:archive)
   let files=["main.swift","Math.swift","Cards.swift","Templates.swift","Update.swift"]
   for name in files {let out=temp.appendingPathComponent(name); try run("/usr/bin/unzip",["-p",archive.path,name],out)}
   let build=temp.appendingPathComponent("Pokerdom Review.app"); let bin=build.appendingPathComponent("Contents/MacOS"); try fm.createDirectory(at:bin,withIntermediateDirectories:true)
   let log=temp.appendingPathComponent("build.log")
   try run("/usr/bin/xcrun",["swiftc"]+files.map{temp.appendingPathComponent($0).path}+["-o",bin.appendingPathComponent("Review").path,"-framework","Cocoa","-framework","Vision"],log)
   let source=try String(contentsOf:temp.appendingPathComponent("main.swift")); let re=try NSRegularExpression(pattern:"Pokerdom Review ([0-9]+\\.[0-9]+)"); guard let m=re.firstMatch(in:source,range:NSRange(source.startIndex...,in:source)),let r=Range(m.range(at:1),in:source) else {throw NSError(domain:"Update",code:3,userInfo:[NSLocalizedDescriptionKey:"Версия не найдена"])}
   let version=String(source[r]); guard requiredVersion == nil || requiredVersion == version else {throw NSError(domain:"Update version",code:1)}; let old=Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0"; guard version.compare(old,options:.numeric) == .orderedDescending else {throw NSError(domain:"Update",code:4,userInfo:[NSLocalizedDescriptionKey:"Пакет не новее установленной версии"])}
   let plist:[String:Any]=["CFBundleExecutable":"Review","CFBundleIdentifier":"local.pokerdom.review","CFBundleName":"Pokerdom Review","CFBundlePackageType":"APPL","CFBundleShortVersionString":version]
   try PropertyListSerialization.data(fromPropertyList:plist,format:.xml,options:0).write(to:build.appendingPathComponent("Contents/Info.plist"))
   try run("/usr/bin/codesign",["--force","--sign","-",build.path],log)
   let backup=current.deletingLastPathComponent().appendingPathComponent("Pokerdom Review backup "+UUID().uuidString+".app")
   try fm.moveItem(at:current,to:backup)
   do {try fm.moveItem(at:build,to:current); try run("/usr/bin/open",["-n",current.path],log)} catch {if fm.fileExists(atPath:current.path){try? fm.removeItem(at:current)}; try fm.moveItem(at:backup,to:current); throw error}
   NSApplication.shared.terminate(nil)
 }
}
