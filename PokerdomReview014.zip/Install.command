#!/bin/bash
set -e
cd "$(dirname "$0")"
LOG="$HOME/PokerdomReview-install.log"
exec > >(tee "$LOG") 2>&1
trap 'echo "Ошибка установки. Журнал: $LOG"; read -r -p "Нажмите Enter для выхода"' ERR
APP="$HOME/Applications/Pokerdom Review.app"
if ! xcode-select -p >/dev/null 2>&1; then
 xcode-select --install
 echo 'Установите инструменты Apple и повторите запуск.'
 exit 0
fi
TMP=$(mktemp -d)
BUILD="$TMP/Pokerdom Review.app"
mkdir -p "$BUILD/Contents/MacOS" "$HOME/Applications"
echo '1/3 Сборка приложения…'
swiftc main.swift Math.swift Cards.swift Templates.swift Update.swift -o "$BUILD/Contents/MacOS/Review" -framework Cocoa -framework Vision
cat > "$BUILD/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?><plist version="1.0"><dict><key>CFBundleExecutable</key><string>Review</string><key>CFBundleIdentifier</key><string>local.pokerdom.review</string><key>CFBundleName</key><string>Pokerdom Review</string><key>CFBundlePackageType</key><string>APPL</string><key>CFBundleShortVersionString</key><string>0.14</string></dict></plist>
PLIST
plutil -lint "$BUILD/Contents/Info.plist"
echo '2/3 Установка…'
if [ -d "$APP" ]; then mv "$APP" "$TMP/previous.app"; fi
if ! mv "$BUILD" "$APP"; then
 if [ -d "$TMP/previous.app" ]; then mv "$TMP/previous.app" "$APP"; fi
 exit 1
fi
echo '3/3 Запуск…'
open -n "$APP"
echo "Готово. Приложение: $APP"
read -r -p 'Нажмите Enter для закрытия установщика.'
