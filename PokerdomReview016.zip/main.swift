import Cocoa
import Vision
import CryptoKit
var lastOCR=""
var baseReport=""
var analysisText=""
var savedText=""
func refreshReport(){ output.string = [baseReport,analysisText,savedText].filter{ !$0.isEmpty }.joined(separator:"\n\n") }
func imageDigest(_ url:URL)throws->String { SHA256.hash(data:try Data(contentsOf:url)).map{String(format:"%02x",Int($0))}.joined() }
let app = NSApplication.shared
app.setActivationPolicy(.regular)
let window = NSWindow(contentRect:NSRect(x:0,y:0,width:800,height:650),styleMask:[.titled,.closable,.resizable],backing:.buffered,defer:false)
window.title="Pokerdom Review 0.16 — архив раздач"
let root=NSStackView(); root.orientation = .vertical; root.alignment = .leading; root.spacing=12; root.edgeInsets=NSEdgeInsets(top:16,left:16,bottom:16,right:16)
window.contentView=root
let intro=NSTextField(wrappingLabelWithString:"Версия 0.16. Откройте сохранённый скриншот завершённой раздачи. Распознавание локальное; карты и суммы требуют проверки. Программа не подключается к игровому столу.")
root.addArrangedSubview(intro)
let preview=NSImageView(); preview.imageScaling = .scaleProportionallyUpOrDown; root.addArrangedSubview(preview); preview.heightAnchor.constraint(equalToConstant:310).isActive=true; preview.widthAnchor.constraint(equalTo:root.widthAnchor,constant:-32).isActive=true
let output=NSTextView(); output.isEditable=false; output.font=NSFont.monospacedSystemFont(ofSize:13,weight:.regular)
let scroll=NSScrollView(); scroll.documentView=output; scroll.hasVerticalScroller=true; root.addArrangedSubview(scroll); scroll.widthAnchor.constraint(equalTo:root.widthAnchor,constant:-32).isActive=true; scroll.heightAnchor.constraint(greaterThanOrEqualToConstant:180).isActive=true
func extract(_ text:String,_ pattern:String)->String? {
 guard let regex=try? NSRegularExpression(pattern:pattern,options:[.caseInsensitive]), let m=regex.firstMatch(in:text,range:NSRange(text.startIndex...,in:text)), let r=Range(m.range(at:1),in:text) else{return nil}; return String(text[r])
}
class Actions:NSObject {
 var archive:URL?
 var timer:Timer?
 var processed=Set<String>()
 var pending=Set<String>()
 @objc func showOCR(){ let alert=NSAlert(); alert.messageText="Исходный OCR"; alert.informativeText=lastOCR; alert.runModal() }
 @objc func journal(){ let dir=FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Documents/Pokerdom Review"); try? FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true,attributes:nil); NSWorkspace.shared.open(dir) }
 @objc func watch(){ let panel=NSOpenPanel(); panel.message="Выберите отдельную папку только с завершёнными раздачами"; panel.canChooseFiles=false; panel.canChooseDirectories=true; guard panel.runModal() == .OK, let dir=panel.url else{return}; archive=dir; pending.removeAll(); timer?.invalidate(); timer=Timer.scheduledTimer(timeInterval:15,target:self,selector:#selector(scan),userInfo:nil,repeats:true); status.stringValue="Архив: \(dir.lastPathComponent)"; scan() }
 @objc func stop(){timer?.invalidate(); timer=nil; archive=nil; status.stringValue="Автоимпорт выключен"}
 @objc func scan(){guard let dir=archive else{return}; let files=(try? FileManager.default.contentsOfDirectory(at:dir,includingPropertiesForKeys:nil)) ?? []; var current=Set<String>(); for url in files where ["png","jpg","jpeg"].contains(url.pathExtension.lowercased()) { guard let digest=try? imageDigest(url) else{continue}; current.insert(digest); if pending.contains(digest) && !processed.contains(digest){process(url); processed.insert(digest)} }; pending=current }


 @objc func open(){
 let panel=NSOpenPanel(); panel.allowedFileTypes=["png","jpg","jpeg"]; guard panel.runModal() == .OK, let url=panel.url else{return}
 process(url)
 }
 @objc func folder(){
 let panel=NSOpenPanel(); panel.canChooseFiles=false; panel.canChooseDirectories=true; guard panel.runModal() == .OK, let dir=panel.url else{return}
 let files=(try? FileManager.default.contentsOfDirectory(at:dir,includingPropertiesForKeys:nil)) ?? []
 var count=0
 for url in files.sorted(by:{$0.path<$1.path}) where ["png","jpg","jpeg"].contains(url.pathExtension.lowercased()) { process(url); count += 1 }
 output.string += "\nОбработано файлов: \(count)"
 }
 func process(_ url:URL){
 preview.image=NSImage(contentsOf:url); baseReport=""; analysisText=""; savedText=""; output.string="Распознавание…"
 let request=VNRecognizeTextRequest(); request.recognitionLevel = .accurate; request.recognitionLanguages=["ru-RU","en-US"]
 do {
 try VNImageRequestHandler(url:url,options:[:]).perform([request])
 let lines=(request.results ?? []).compactMap{$0.topCandidates(1).first?.string}
 let raw=lines.joined(separator:"\n")
 let bank=extract(raw,#"банк[ \t]*[:：]?[ \t]*([0-9]+(?:[ \u00a0][0-9]{3})*)(?![0-9.,])"#) ?? "не распознан"
 let foundCombos=lines.filter{line in ["фулл-хаус","две пары","стрит","флеш","каре","тройка","сет","пара"].contains{line.lowercased().contains($0)}}
 var seen=Set<String>()
 let combos=foundCombos.filter{seen.insert($0.lowercased().trimmingCharacters(in:.whitespaces)).inserted}
 let shortDeck=raw.contains("6+"); format.state = shortDeck ? .on : .off
 let seats:[(String,Double,Double)] = [("Слева сверху",0.16,0.61),("Сверху",0.54,0.74),("Справа сверху",0.92,0.61),("Слева снизу",0.14,0.20),("Справа снизу",0.94,0.20),("Ваш стек",0.54,0.06)]
 let stackCandidates=seats.map { seat -> String in
   let region=CGRect(x:max(0,seat.1-0.075),y:max(0,seat.2-0.035),width:min(1,seat.1+0.075)-max(0,seat.1-0.075),height:0.07)
   let local=VNRecognizeTextRequest(); local.recognitionLevel = .accurate; local.recognitionLanguages=["en-US","ru-RU"]; local.usesLanguageCorrection=false; local.regionOfInterest=region
   do {try VNImageRequestHandler(url:url,options:[:]).perform([local])} catch {return "\(seat.0): не распознан"}
   let values=(local.results ?? []).compactMap { observation -> Int? in
     guard let c=observation.topCandidates(1).first,c.confidence >= 0.65 else{return nil}
     let value=c.string.replacingOccurrences(of:" ",with:"").replacingOccurrences(of:"\u{00a0}",with:"").replacingOccurrences(of:"\u{202f}",with:"")
     guard value.range(of:#"^[0-9]+$"#,options:.regularExpression) != nil else{return nil}; return Int(value)
   }
   let unique=Set(values)
   guard unique.count == 1,let value=unique.first else{return "\(seat.0): не распознан"}
   return "\(seat.0): \(value)"
 }
 heroField.stringValue=""; oppField.stringValue=""; boardField.stringValue=""
 let detected = recognizeArchivedCards(url)
 if let (h,o,b)=detected { heroField.stringValue=h; oppField.stringValue=o; boardField.stringValue=b }
 let cardReport = detected == nil ? "Карты: не распознаны уверенно; проверьте вручную." : "Карты: предварительно заполнены; подтвердите визуально перед разбором."
 let report="Файл: \(url.lastPathComponent)\nБанк: \(bank)\nФормат: \(shortDeck ? "6+ Холдем (кандидат)" : "не определён")\nКомбинации: \(combos.isEmpty ? "не распознаны" : combos.joined(separator:"; "))\nСтеки (проверьте):\n\(stackCandidates.joined(separator: "\n"))\n\(cardReport)"
 if detected != nil { analysisText = "Сверьте карты и формат игры, затем нажмите «Разбор»." }
 lastOCR=raw
 baseReport=report; refreshReport()
 let dir=FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Documents/Pokerdom Review")
 do {try FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true,attributes:nil); try (report+"\n\n"+analysisText).write(to:dir.appendingPathComponent((try imageDigest(url))+".txt"),atomically:true,encoding:.utf8); savedText="Отчёт сохранён в Документы/Pokerdom Review"; refreshReport()} catch {output.string += "\n\nНе удалось сохранить отчёт: \(error.localizedDescription)"}
 } catch {output.string="Ошибка: \(error.localizedDescription)"}
 }
}
let fields=NSStackView(); fields.orientation = .horizontal
let heroField=NSTextField(string: ""); heroField.placeholderString="Ваши: KS KD"
let oppField=NSTextField(string: ""); oppField.placeholderString="Соперник: AD TH"
let boardField=NSTextField(string: ""); boardField.placeholderString="Стол: KH 6D AC TD 6C"
let format=NSButton(checkboxWithTitle:"6+",target:nil,action:nil)
for f in [heroField,oppField,boardField] {f.widthAnchor.constraint(equalToConstant:f === boardField ? 220:140).isActive=true; fields.addArrangedSubview(f)}
fields.addArrangedSubview(format)
class MathAction:NSObject { @objc func calculate(){guard let h=parseCards(heroField.stringValue),let o=parseCards(oppField.stringValue),let b=parseCards(boardField.stringValue) else {output.string += "\nПроверьте формат карт: KS KD (C/D/H/S).";return}; analysisText=retrospective(h,o,b,short:format.state == .on); refreshReport() } }
let mathAction=MathAction(); fields.addArrangedSubview(NSButton(title:"Разбор",target:mathAction,action:#selector(MathAction.calculate))); root.insertArrangedSubview(fields,at:1)
let actions=Actions(); let button=NSButton(title:"Открыть скриншот",target:actions,action:#selector(Actions.open)); let controls=NSStackView(views:[button,NSButton(title:"Папка раздач",target:actions,action:#selector(Actions.folder)),NSButton(title:"Показать OCR",target:actions,action:#selector(Actions.showOCR))]); root.insertArrangedSubview(controls,at:1)
let status=NSTextField(labelWithString:"Автоимпорт выключен")
let archiveControls=NSStackView(views:[NSButton(title:"Следить за архивом",target:actions,action:#selector(Actions.watch)),NSButton(title:"Остановить",target:actions,action:#selector(Actions.stop)),NSButton(title:"Журнал отчётов",target:actions,action:#selector(Actions.journal)),status]); root.insertArrangedSubview(archiveControls,at:2)
let updateAction = UpdateAction()
root.insertArrangedSubview(NSStackView(views:[NSButton(title:"Проверить обновления",target:updateAction,action:#selector(UpdateAction.check)),NSButton(title:"Установить ZIP…",target:updateAction,action:#selector(UpdateAction.install))]),at:1)
window.isReleasedWhenClosed=false; window.center(); window.makeKeyAndOrderFront(nil); app.activate(ignoringOtherApps:true); DispatchQueue.main.async { updateAction.checkRemote(silent:true) }; app.run()
