import Cocoa
import CoreGraphics
import ImageIO
// Fixed layout prototype, calibrated only for the supplied showdown screenshot.
func recognizeArchivedCards(_ url: URL) -> (String,String,String)? {
 guard let source=CGImageSourceCreateWithURL(url as CFURL,nil),let image=CGImageSourceCreateImageAtIndex(source,0,nil) else{return nil}
 let w=1371,h=1088
 guard abs(Double(image.width)/Double(image.height)-Double(w)/Double(h))<0.035 else{return nil}
 guard let ctx=CGContext(data:nil,width:w,height:h,bitsPerComponent:8,bytesPerRow:w*4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue) else{return nil}
 ctx.draw(image,in:CGRect(x:0,y:0,width:w,height:h))
 guard let normalized=ctx.makeImage() else{return nil}
 func match(_ x:Int,_ y:Int,_ kind:String)->String? {
 let rect = kind == "rank" ? CGRect(x:x+3,y:y+3,width:37,height:48) : CGRect(x:x+3,y:y+55,width:35,height:39)
 guard let crop=normalized.cropping(to:rect),let small=CGContext(data:nil,width:24,height:24,bitsPerComponent:8,bytesPerRow:96,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue) else{return nil}
 small.draw(crop,in:CGRect(x:0,y:0,width:24,height:24)); guard let data=small.data else{return nil}; let bytes=data.assumingMemoryBound(to:UInt8.self)
 let mask=(0..<576).map { i in min(bytes[i*4],min(bytes[i*4+1],bytes[i*4+2])) < 145 }
 var scores=[String:Double]()
 for (type,label,bits) in templates where type==kind {let target=Array(bits); let d=Double(zip(mask,target).filter{$0.0 != ($0.1 == "1")}.count)/576; scores[label]=min(scores[label] ?? 1,d)}
 let ordered=scores.sorted{$0.value<$1.value}; guard ordered.count>1,ordered[0].value<0.13,ordered[1].value-ordered[0].value>0.025 else{return nil};return ordered[0].key
 }
 func cards(_ points:[(Int,Int)])->String? {var result=[String]();for (x,y) in points {guard let r=match(x,y,"rank"),let s=match(x,y,"suit") else{return nil};result.append(r+s)};return result.joined(separator:" ")}
 guard let hero=cards([(671,809),(712,809)]),let opp=cards([(126,654),(167,654)]),let board=cards([(478,466),(585,466),(692,466),(799,466),(906,466)]),let all=parseCards(hero+" "+opp+" "+board),Set(all).count==9 else{return nil}
 return (hero,opp,board)
}
